int existeConectividade(int g, int borda, double r, double eps, double d1x, double d1y, double d2x, double d2y);
